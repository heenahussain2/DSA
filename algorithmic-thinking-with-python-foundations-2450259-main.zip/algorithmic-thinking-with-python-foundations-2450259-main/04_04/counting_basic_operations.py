n = 100  # Assignment statement
count = 0  # Assignment statement
while count < n:  # Comparison statement
    count += 1  # Arithmetic operation (and assignment!)
    print(count)  # Output statement

